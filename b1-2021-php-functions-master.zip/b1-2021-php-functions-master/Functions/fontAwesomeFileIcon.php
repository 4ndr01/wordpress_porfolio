<?php

/**
 * Créer une fonction "fontAwesomeFileIcon" permettant de retourner
 * l'icone FontAwesome correspondant à un nom de fichier.
 *
 * Exemples :
 * ("resume.docx") => "<i class="fa fa-word-o"></i>"
 * ("~/Documents/charts.pdf") => "<i class="fa fa-pdf-o"></i>",
 * ("todo.txt") => "<i class="fa fa-text-o"></i>"
 * ("birthday.avi") => "<i class="fa fa-video-o"></i>"
 */

if