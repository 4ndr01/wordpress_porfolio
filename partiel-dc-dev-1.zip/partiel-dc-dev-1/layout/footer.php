<footer class="footer-container container">
    <div class="footer-main">
        <ul class="footer-nav">
            <li><a href="index.php">Accueil</a></li>
            <li><a href="#">Actualités</a></li>
            <li><a href="#">Nos Chambres</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
        <!-- TODO: Afficher automatiquement l'année en cours en PHP pour le copyright -->
        <p>Copyright 2022 Tous droits réservés</p>
    </div>
    <div class="footer-secondary"></div>
</footer>

</body>
</html>